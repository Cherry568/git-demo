package com.myweb;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class LoginFilter implements Filter{
	
	private static Logger logger = Logger.getLogger(LoginFilter.class.getName());

	public void doFilter(ServletRequest req, ServletResponse rsp, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)rsp;
		
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("username");
		
		if(session.getAttribute("username")==null){
			logger.debug("�û�δ��¼!");
			response.sendRedirect("login.jsp"); 	
			return;
		}else{
			chain.doFilter(request, response);
		}
	}

	public void init(FilterConfig arg0) throws ServletException {
	}
	
	//@Override****��myeclipse�в���д@Override
	public void destroy() {
	}
}