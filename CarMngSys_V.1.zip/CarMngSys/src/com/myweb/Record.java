package com.myweb;

import java.util.Date;

public class Record {
	private int id;
	private String carPai;
	private Date carStart;
	private Date carEnd;
	private String carEntrance;
	private String carExit;
	public String getCarPai() {
		return carPai;
	}
	public void setCarPai(String carPai) {
		this.carPai = carPai;
	}
	public Date getCarStart() {
		return carStart;
	}
	public void setCarStart(Date carStart) {
		this.carStart = carStart;
	}
	public Date getCarEnd() {
		return carEnd;
	}
	public void setCarEnd(Date carEnd) {
		this.carEnd = carEnd;
	}
	public String getCarEntrance() {
		return carEntrance;
	}
	public void setCarEntrance(String carEntrance) {
		this.carEntrance = carEntrance;
	}
	public String getCarExit() {
		return carExit;
	}
	public void setCarExit(String carExit) {
		this.carExit = carExit;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}
