package com.myweb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class RecordID {
	private static Logger logger = Logger.getLogger(RecordID.class.getName());
	public int getID(Object chewei_id) {
		
		int id = 0;
		//����SQL���
		String sql = "select * from chewei where chewei_id=?";
		logger.debug(sql);
		Connection conn = DBUtil.getConn();
		//ִ�в�ѯ����ȡ���г�λ�Ľ����
		ResultSet rs = DBUtil.executeQuery(conn,sql,chewei_id);
		try {
			Record record = new Record();
			//װ��ͣ����¼����
			while (rs.next()) {
				record.setId(rs.getInt("id"));
				id = record.getId();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, null, rs);
		}
		logger.debug("��ѯ����ID�ǣ�"+id);
		return id;
	}
}