package com.myweb;

public class Car {
	private int carID;
	private String carArea;
	private String carState;
	public String getCarState() {
		return carState;
	}
	public void setCarState(String carState) {
		this.carState = carState;
	}
	public int getCarID() {
		return carID;
	}
	public void setCarID(int carID) {
		this.carID = carID;
	}
	public String getCarArea() {
		return carArea;
	}
	public void setCarArea(String carArea) {
		this.carArea = carArea;
	}
}
