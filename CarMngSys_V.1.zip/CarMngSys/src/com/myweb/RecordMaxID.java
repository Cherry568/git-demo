package com.myweb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class RecordMaxID {
	private static Logger logger = Logger.getLogger(RecordMaxID.class.getName());
	public int getMaxID() {
		
		int id = 0;
		//����SQL���
		String sql = "select * from ting where id=( select max(id) from  ting )";
		Connection conn = DBUtil.getConn();
		//ִ�в�ѯ����ȡ���г�λ�Ľ����
		ResultSet rs = DBUtil.executeQuery(conn, sql);
		try {
			List<Record> list = new ArrayList<Record>();
			Record record = new Record();
			//װ��ͣ����¼����
			while (rs.next()) {
				record.setId(rs.getInt("id"));
			}
			id = record.getId()+1;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, null, rs);
		}
		return id;
	}
	//����
	public static void main(String arg[]){
		RecordMaxID max_id = new RecordMaxID();
		int id = max_id.getMaxID();
		System.out.println(id);
	}
}
