package com.myweb.struts.action;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.myweb.DBUtil;
import com.myweb.struts.form.LoginForm;

public class ModifyAction extends DispatchAction { //���������������ʱʹ��
	private static Logger logger = Logger.getLogger(ModifyAction.class.getName());
	public ActionForward execute(ActionMapping mapping,ActionForm form,
		HttpServletRequest request,HttpServletResponse response) {
		LoginForm f = (LoginForm) form;
		String sql = "update admin set  password=? where username=?";
		logger.info(sql);
		Connection conn = DBUtil.getConn();
		int rst = DBUtil.executeUpdate(conn, sql, f.getPassword(),f.getUsername());
		//�жϳɹ����
		if (rst>0)
			request.setAttribute("msg", "������Ϣ�޸ĳɹ�");
		DBUtil.close(conn, null, null);
		return mapping.findForward("login");
	} 
}
