package com.myweb.struts.action;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.validator.LazyValidatorForm;

import com.myweb.DBUtil;
import com.myweb.RecordID;

public class LeaveAction extends DispatchAction { 
	private static Logger logger = Logger.getLogger(LeaveAction.class.getName());
	protected ActionForward unspecified(ActionMapping mapping,ActionForm form,  
            HttpServletRequest request,HttpServletResponse response){  
        LazyValidatorForm f = (LazyValidatorForm) form;
		//����SQL���,�����Զ����ֶ���Ϊexit
		String sqlLeave = "update ting set endtime=?,carexit=?,state=? where id=?";
		logger.info(sqlLeave);
		Connection conn = DBUtil.getConn();
		
		//��ȡ��λID
		Object chewei_id = f.get("chewei_ID");
		logger.debug("chewei_ID:"+chewei_id);
		//���峵λ״̬
		String state = "����";
		int id = new RecordID().getID(chewei_id);
		logger.info("�����뿪�ļ�¼id:"+id);
		
		int rst = DBUtil.executeUpdate(conn,sqlLeave,f.get("carEnd"),f.get("carExit"),state,id);
		//�жϳɹ����
		if (rst>0) {
			request.setAttribute("msg", "�����뿪�ɹ�");
			logger.info("�����뿪�ɹ�");
		}
		int rs = DBUtil.executeUpdate(conn, "update chewei set state=? where chewei_id=?", state,chewei_id);
		if(rs>0)
			logger.info("��λ״̬���³ɹ�");
		DBUtil.close(conn, null, null);
		return mapping.findForward("ting_info_ting");  
    }  
}
