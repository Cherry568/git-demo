package com.myweb.struts.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.myweb.struts.form.LoginForm;
import java.sql.Connection;
import java.sql.SQLException;

import com.myweb.DBUtil;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

public class LoginAction extends Action {
	private static Logger logger = Logger.getLogger(LoginAction.class.getName());
	
	//�г����г�λ��Ϣ
	public ActionForward execute(ActionMapping mapping,ActionForm form,
		HttpServletRequest request,HttpServletResponse response) {
		//�õ���¼form
		LoginForm f = (LoginForm) form;
		logger.info("username:"+f.getUsername());
		logger.info("password:"+f.getPassword());
		//����ת���ĵ�ַ����
		String forward = null;
		//�������Ա��¼��SQL���
		String sql = "select * from admin where username=? and password=?";
		Connection conn = DBUtil.getConn();
		ResultSet rs = DBUtil.executeQuery(conn, sql, f.getUsername(),f.getPassword());
		try {
			//��¼�ɹ�
			if (rs.next()) {
				request.getSession().setAttribute("username", rs.getString("username"));
				logger.debug("��¼�ɹ�");
				forward = "index";
			}else{
				//ʧ���򷵻ص�¼����
				logger.debug("��¼ʧ��");
				forward = "login";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//�ر�����
			DBUtil.close(conn, null, rs);
		}
		return mapping.findForward(forward);
	}
}