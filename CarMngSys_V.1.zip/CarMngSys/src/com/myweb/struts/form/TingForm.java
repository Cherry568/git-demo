package com.myweb.struts.form;

import java.util.Date;

public class TingForm {
	
	private String car_Pai;
	private Date car_Start;
	private Date car_End;
	private String car_Entrance;
	private String car_Exit;
	public String getCar_Pai() {
		return car_Pai;
	}
	public void setCar_Pai(String car_Pai) {
		this.car_Pai = car_Pai;
	}
	public Date getCar_Start() {
		return car_Start;
	}
	public void setCar_Start(Date car_Start) {
		this.car_Start = car_Start;
	}
	public Date getCar_End() {
		return car_End;
	}
	public void setCar_End(Date car_End) {
		this.car_End = car_End;
	}
	public String getCar_Entrance() {
		return car_Entrance;
	}
	public void setCar_Entrance(String car_Entrance) {
		this.car_Entrance = car_Entrance;
	}
	public String getCar_Exit() {
		return car_Exit;
	}
	public void setCar_Exit(String car_Exit) {
		this.car_Exit = car_Exit;
	}
	
}
