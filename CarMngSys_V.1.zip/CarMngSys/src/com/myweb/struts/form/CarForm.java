package com.myweb.struts.form;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.*;

public class CarForm extends ActionForm {
	private int chewei_ID;
	private String chewei_Area;
	
	public int getChewei_ID() {
		return chewei_ID;
	}
	public void setChewei_ID(int chewei_ID) {
		this.chewei_ID = chewei_ID;
	}
	public String getChewei_Area() {
		return chewei_Area;
	}
	public void setChewei_Area(String chewei_Area) {
		this.chewei_Area = chewei_Area;
	}
	
	public void reset(ActionMapping mapping,HttpServletRequest request) {
		super.reset(mapping, request);
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}
