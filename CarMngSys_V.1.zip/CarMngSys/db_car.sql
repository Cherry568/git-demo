/*
Navicat MySQL Data Transfer

Source Server         : his
Source Server Version : 50150
Source Host           : localhost:3306
Source Database       : db_car

Target Server Type    : MYSQL
Target Server Version : 50150
File Encoding         : 65001

Date: 2017-04-13 10:05:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('a', 'aa');
INSERT INTO `admin` VALUES ('西伯利亚小狼', '123');

-- ----------------------------
-- Table structure for `chewei`
-- ----------------------------
DROP TABLE IF EXISTS `chewei`;
CREATE TABLE `chewei` (
  `chewei_id` int(11) NOT NULL DEFAULT '0',
  `chewei_area` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`chewei_id`),
  KEY `state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chewei
-- ----------------------------
INSERT INTO `chewei` VALUES ('1', 'A区', '占用', '6');
INSERT INTO `chewei` VALUES ('2', 'A区', '空闲', '5');
INSERT INTO `chewei` VALUES ('3', 'B区', '空闲', null);
INSERT INTO `chewei` VALUES ('4', 'B区', '空闲', null);

-- ----------------------------
-- Table structure for `ting`
-- ----------------------------
DROP TABLE IF EXISTS `ting`;
CREATE TABLE `ting` (
  `id` int(11) NOT NULL DEFAULT '0',
  `chewei_id` int(11) DEFAULT NULL,
  `chepai` varchar(255) DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `entrance` varchar(255) DEFAULT NULL,
  `carexit` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chewei_id` (`chewei_id`),
  KEY `state` (`state`),
  CONSTRAINT `chewei_id` FOREIGN KEY (`chewei_id`) REFERENCES `chewei` (`chewei_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ting
-- ----------------------------
INSERT INTO `ting` VALUES ('1', '1', 'A11111', '2017-04-01 16:07:02', '2017-04-06 16:39:47', 'NO.1', 'NO.2', '空闲');
INSERT INTO `ting` VALUES ('2', '1', 'A999999', '2017-04-01 16:07:02', '2017-04-06 16:39:47', 'NO.1', 'NO.2', '空闲');
INSERT INTO `ting` VALUES ('3', '1', 'A11111', '2017-04-05 09:04:57', '2017-04-05 09:04:10', 'NO.1', 'NO.1', '空闲');
INSERT INTO `ting` VALUES ('4', '1', 'A11111', '2017-04-05 09:04:58', '2017-03-29 09:03:11', 'NO.1', 'NO.1', '空闲');
INSERT INTO `ting` VALUES ('5', '2', 'A11111', '2017-04-04 09:04:09', '2017-04-06 09:04:24', 'NO.1', 'NO.1', '空闲');
INSERT INTO `ting` VALUES ('6', '1', 'A11111', '2017-04-01 10:04:56', null, 'NO.1', null, '占用');
